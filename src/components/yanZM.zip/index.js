import Identify from './identify.vue'

export default Identify
